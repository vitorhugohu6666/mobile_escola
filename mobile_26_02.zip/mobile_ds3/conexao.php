<?php
$servername = "localhost";
$username = "root";
$password = "";
$database = "mobile_ds3";

$conection = mysqli_connect($servername, $username, $password, $database);
