<?php
session_start();
?>

<!doctype html>
<html lang="pt-br">

<head>

	<!-- Required meta tags -->
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">

	<!-- CSS Boostrapp -->
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
	<link rel="stylesheet" href="estilo/signin.css">
	<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.13.1/font/bootstrap-icons.min.css">
	<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css">

	<title>ACESSO AO SISTEMA</title>

	<!-- Config Atalho Mobile -->
	<link rel="manifest" href="manifest.json">
	<meta name="msapplication-TileColor" content="#ffffff">
	<meta name="msapplication-TileImage" content="/192x.png">
	<meta name="theme-color" content="#ffffff">

</head>

<style>
	.img {
		width: 300px;
		height: 300px;
		border-radius: 10px;
	}
</style>

<script type="text/javascript">
	function redirectTime() {
		//window.location = "manutencao.php"
	}
</script>

<body onLoad="(redirectTime())" class="p-3 bg-dark">

	<div class="container">
		<div class="row justify-content-center">
			<div class="col-sm-6">
				<div class="card">

					<br>

					<center>
						<img src="imagens/logo.png" class="img-fluid img" alt="..." style="margin-top: 50px;">
					</center>

					<center>
						<div class="card-body">
							<h5 class="card-title">Acesso ao Sistema</h5>

							<form method="POST" action="valida_login.php">

								<div class="form-floating mb-3">
									<input type="text" class="form-control" id="input_usuario"
										name="usuario" placeholder="Usuário" required>
									<label for="floatingName">Usuário</label>
								</div>

								<div class="form-floating">
									<input type="password" class="form-control" id="input_senha"
										name="senha" placeholder="Usuário" required>
									<label for="floatingPassword">Senha</label>
								</div>

								</p>
								<input type="submit" class="btn btn-primary" value="Entrar">
								</p>

								<?php
								if (isset($_GET["erro"]) and ($_GET["erro"]) == 1) {
									echo '<div class="alert alert-danger" role="alert" style="margin-top: 30px;">
									<i class="bi bi-exclamation-triangle-fill"></i> Usuário ou senha incorretos. Tente novamente!
									</div>';

									header("Refresh: 3; url=./login.php");
								}

								if (isset($_GET["acesso_dashboard"]) and ($_GET["acesso_dashboard"]) == 1) {
									echo '<div class="alert alert-danger" role="alert">
									<i class="bi bi-exclamation-triangle-fill"></i> É preciso fazer login antes!
									</div>';

									header("Refresh: 3; url=./login.php");
								}
								?>
							</form>
						</div>
					</center>

				</div>
			</div>
		</div>
	</div>

	<!-- Option 1: Bootstrap Bundle with Popper -->
	<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"
		integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM"
		crossorigin="anonymous"></script>

</body>

</html>