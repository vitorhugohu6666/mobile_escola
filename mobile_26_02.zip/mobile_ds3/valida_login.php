<?php
session_start();
include("conexao.php");

$usuario = $_POST["usuario"];
$senha = $_POST["senha"];

$dados = mysqli_query($conection, "SELECT * FROM usuarios WHERE usuario = '$usuario'");
$resultado_usuarios = mysqli_fetch_assoc($dados);

// $id_usuario = $resultado_usuarios['id'];
$usuarioBanco = $resultado_usuarios['usuario'];
$senhaBanco = $resultado_usuarios['senha'];


//$usuario_email = $resultado_usuarios['email'];

//$email_usuario = $resultado_usuarios['email'];


if (($usuario == $usuarioBanco) && ($senha == $senhaBanco)) {
    $_SESSION["acesso"] = $usuario;

    header('Location: dashboard.php');
} else {
    header('Location: login.php?erro=1');
}
