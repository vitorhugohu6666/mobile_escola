<?php
session_start();

// Limpa todas as variáveis
$_SESSION = [];

// Destrói a sessão
session_destroy();

// Redireciona para login
header("Location: login.php");
exit;
