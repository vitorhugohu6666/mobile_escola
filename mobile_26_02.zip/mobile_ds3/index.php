<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <title>BEM VINDO!</title>

    <style>
        .img {
            width: 300px;
            height: 300px;
            border-radius: 10px;
        }
    </style>
</head>

<script type="text/javascript">
    function redirectTime() {
        window.location = "login.php"
        // window.location = "manutencao.php"
    }
</script>

<body onload="setTimeout('redirectTime()', 2000)" class="p-3 mb-2 bg-primary">
    <center><img src="imagens/logo.png" class="img-fluid img" alt="Logo principal"></center>

    <br>

    <center>
        <div class="spinner-border" role="status">
            <span class="visually-hidden">Carregamento...</span>
        </div>
    </center>

    <center>
        <p class="text-light">Bem vindo! carregando o sistema...</p>

    </center>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM"
        crossorigin="anonymous"></script>

</body>

</html>