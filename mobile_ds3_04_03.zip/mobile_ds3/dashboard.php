<?php
session_start();

if(!isset($_SESSION["acesso"])) {
    header('Location: login.php?acesso_dashboard=1');
    exit;
}

$mobile = FALSE;
$user_agents = array("iPhone", "iPad", "Android", "webOS", "BlackBerry", "iPod", "Symbian", "IsGeneric");

foreach ($user_agents as $user_agent) {
    if (strpos($_SERVER['HTTP_USER_AGENT'], $user_agent) !== FALSE) {        /* a funcao strpos verifica se a string $user_agent
                                                                                    está contida na string $_server */

        $mobile = TRUE;
        $modelo = $user_agent;
        break;
    }
}

/* if ($mobile) {
    echo "Acesso feito via " . strtolower($modelo);
} else {
    echo "Acesso feito via computador";
}
echo '<br>' . $_SERVER['HTTP_USER_AGENT'];
*/
?>

<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <link rel="canonical" href="https://getbootstrap.com/docs/5.0/examples/sticky-footer-navbar/">
    <link href="../assets/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.13.1/font/bootstrap-icons.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css">
    <title>Sistema</title>

    <style>
        body {
            display: flex;
            flex-direction: column;
            min-height: 100vh;
        }

        main {
            flex: 1;
            display: flex;
            justify-content: center;
            align-items: center;
            padding: 20px;
        }

        a {
            background-color: red;
            text-align: center;
            text-decoration: none;
            color: white;
            width: 80px;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            border-radius: 8px;
        }

        a:hover {
            background-color: #d45d5d;
            color: white;
        }

        #header {
            display: flex;
            justify-content: space-between;
        }
    </style>
</head>

<body class="bg-dark text-white">

    <?php if ($mobile): ?>

        <header class="bg-light p-3 text-muted">
            <h1>Bem-vindo ao Sistema Mobile</h1>
            <a href="logout.php">Sair</a>
        </header>

        <main>
            <div style="display: flex; ">
                Lorem ipsum dolor sit, amet consectetur adipisicing elit. Ratione voluptate eligendi sapiente
                recusandae incidunt eos consectetur ad modi numquam soluta officia quibusdam, ab iste nobis
                possimus aperiam deserunt ullam architecto?
                Lorem ipsum dolor sit, amet consectetur adipisicing elit. Ratione voluptate eligendi sapiente
                recusandae incidunt eos consectetur ad modi numquam soluta officia quibusdam, ab iste nobis
                possimus aperiam deserunt ullam architecto?
                Lorem ipsum dolor sit, amet consectetur adipisicing elit. Ratione voluptate eligendi sapiente
                recusandae incidunt eos consectetur ad modi numquam soluta officia quibusdam, ab iste nobis
                possimus aperiam deserunt ullam architecto?
            </div>
        </main>


        <footer class="footer mt-auto py-3 bg-light">
            <div class="container">
                <span class="text-muted">&copy; <span id="ano"></span> Site desenvolvido pelo Vitor Hugo</span>
            </div>
        </footer>

    <?php else: ?>

        <header class="bg-light p-2 text-muted" id="header">
            <h2>Bem-vindo ao Sistema Desktop</h2>
            <a href="logout.php">Sair</a>
        </header>

        <main>
            <div style="display: flex; ">
                Lorem ipsum dolor sit, amet consectetur adipisicing elit. Ratione voluptate eligendi sapiente
                recusandae incidunt eos consectetur ad modi numquam soluta officia quibusdam, ab iste nobis
                possimus aperiam deserunt ullam architecto?
                Lorem ipsum dolor sit, amet consectetur adipisicing elit. Ratione voluptate eligendi sapiente
                recusandae incidunt eos consectetur ad modi numquam soluta officia quibusdam, ab iste nobis
                possimus aperiam deserunt ullam architecto?
                Lorem ipsum dolor sit, amet consectetur adipisicing elit. Ratione voluptate eligendi sapiente
                recusandae incidunt eos consectetur ad modi numquam soluta officia quibusdam, ab iste nobis
                possimus aperiam deserunt ullam architecto?
            </div>
        </main>


        <footer class="footer mt-auto py-3 bg-light">
            <div class="container">
                <span class="text-muted">&copy; <span id="ano"></span> Site desenvolvido pelo Vitor Hugo</span>
            </div>
        </footer>

    <?php endif; ?>


    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
    <script>
        let ano = window.document.getElementById("ano")
        let anoAtual = new Date().getFullYear()
        ano.innerHTML = anoAtual
    </script>
</body>

</html>